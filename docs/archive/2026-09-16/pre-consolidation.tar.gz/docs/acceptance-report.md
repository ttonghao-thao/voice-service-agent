# 一期应用验收记录

## 2026-09-15 审查复验补充

- `uv run --locked pytest -q`：44 passed，1 条 Starlette/AnyIO 上游弃用警告。
- `uv run --locked ruff check apps/api tests scripts`：通过。
- `npm test --prefix apps/web`：6 passed。
- `npm run build --prefix apps/web`：TypeScript/Vite 通过。
- 本轮未执行浏览器 E2E、真实麦克风/播放、VoiceChat/CueKB/文本模型/SSO 联调，以及 PostgreSQL/Redis/Docker、故障和性能验收。合成响应测试不证明 CueKB 原生 API 已接通。
- 本轮无应用代码变更，集成缺口与待确认方案见 [集成提案](customer-voice-cuekb-proposal.md)。以下保留 2026-09-05 的历史结果，不将其作为本轮重新执行的结果。

## 一期历史验收

日期：2026-09-05。**当前交付为已实现并通过本地验证的应用代码；真实服务和生产部署验收仍待完成。** 本报告逐项对应设计方案第 17 节，不把合成模型、合成麦克风、SQLite 或 Redis 命令夹具等同于真实云端/生产组件。

## 已执行的验证

| 检查 | 结果 | 实际环境/范围 |
| --- | --- | --- |
| Python pytest | 44 passed | Python 3.12.13，隔离 SQLite，真实 Agents SDK 循环 + 合成 HTTP/provider 响应；包含生产容器静态契约 |
| Ruff | 通过 | 后端、迁移、脚本和 Python 测试 |
| 音频单元测试 | 6 passed | Node.js；连续重采样、44.1/48kHz 时长、抗混叠、PCM16、缓冲硬上限与清空 |
| 前端 TypeScript/Vite 构建 | 通过 | 生产构建，依赖拆包后无超 500KB chunk 警告 |
| Playwright 浏览器 | 5 passed | Chromium；中文文字/引用、历史恢复、390px 窄屏、麦克风拒绝降级、管理员工具启停/服务状态、合成麦克风持续传输/静音/打断/结束 |
| 后端启动/健康 | 通过 | 本机 FastAPI，SQLite、开发身份与 mock 配置；不表示真实模型 ready |
| Alembic | 通过 | 空 SQLite 升级 0001→0003、downgrade base 后重升级、schema 差异 check；另生成 PostgreSQL 离线 SQL |
| PostgreSQL/Redis/Docker | 未运行 | 没有 Docker/数据库/Redis 运行环境；离线 SQL 和命令契约不能替代实测 |
| P0 云端连接脚本 | blocked | 缺少 VOICECHAT_WS_URL，真实连接次数为零 |

Python 运行仍有一条 Starlette TestClient 对 AnyIO `BlockingPortal` 别名的上游弃用警告；无测试失败。Playwright 的 NO_COLOR/FORCE_COLOR 警告只影响终端颜色。

## A01–A22

| 编号 | 应用验证及结果 | 真实验收尚未完成的部分 |
| --- | --- | --- |
| A01 中文文字公司知识 | SDK 的 run/run_streamed 实际循环使用合成 HTTP 响应，调用授权 RAG、生成有效引用；门户可显示中文 | 真实文本模型与授权知识库的业务正确性 |
| A02 中文语音天气 | 原生事件映射、同 call_id 回传和中文载荷契约已测；天气结构化契约已测 | 真实中文语音→天气→口述完整链路 |
| A03 “那明天呢” | 地点时区解析已测；代码保存已确认地点/单位/日期 slots，历史有界持久化 | 实际模型基于已确认 slots 的追问准确率 |
| A04 地点缺失/歧义 | 天气多地点结果确定性返回澄清，已测；提示词禁止猜地点 | 实际模型是否始终不杜撰地点 |
| A05 无依据/冲突 | 空 RAG、无证据 affirmative 回答及伪造引用拦截已测；代码对 conflict/同文档多版本拒绝自动选用 | 真实知识相关性、有效版本与复杂来源冲突样本 |
| A06 工具等待仍收音 | 工具 worker 与音频收发分离；超时测试和连续合成音频浏览器测试通过 | 真实 3–5 秒工具等待下的双向连续音频与提示时序 |
| A07 播放时硬打断 | ring clear 后旧样本不恢复；浏览器按钮与重建路径已测 | 实际扬声器端停止延迟 P95 与晚到原生音频 |
| A08 查询中切换城市 | 抗取消旧任务晚到不能提交、旧 run 被新文字取消已测；浏览器重建 epoch 已测 | 真实语音工具等待阶段换城市的口述结果 |
| A09 结果与打断竞态 | canceled/epoch/turn fence 与重复 interrupt 不取消新轮次已测 | 云端写回时序与真实音频漏播统计 |
| A10 停顿/附和/插话 | 自动 VAD 打断未开放；保留确定性按钮 | 0.3/0.8/1.5 秒停顿及误取消专项，未测 |
| A11 重复 call/transcript | call_id 一次执行、票据重放拒绝、done 转写去重已测 | 真实云端事件重放样例 |
| A12 工具先于最终转写 | 脚本化事件按该顺序到达，业务只执行一次，转写分别留档，已测 | 实际云端如无直接关联字段，不伪造 call 与 input item 的一一关系 |
| A13 用户/租户隔离 | 对象访问、签名 JWT tenant/audience/ACL、工具知识库交集已测 | 真实 SSO、RAG ACL 和多用户语音并发 |
| A14 断网/关闭/重启 | WebSocket 清理、票据过期、startup recovery、lease 命令隔离已测；实际浏览器结束释放已测 | PostgreSQL/Redis 及负载均衡故障切换、网络分区 |
| A15 RAG 注入 URL 指令 | 资料保留为文本，未触发任意 URL 请求，javascript 外链被移除，已测 | 真实文本模型上的提示注入评测 |
| A16 错误 JSON/过大/5xx | 32KB 限制、JSON 错误、有限重试、工具总超时已测；429 不自动重试 | 真实供应商限流和重试预算 |
| A17 超过两分钟会话 | 业务历史外置、105秒应用轮换、首次摘要及 slots 已实现 | 真实模型状态衰减、跨轮换损失及长对话，未测 |
| A18 中文完整往返 | 中文问题、schema 参数、工具载荷、引用及门户显示已测 | 云端中文音频与语音字幕质量 |
| A19 文字/语音同时发生 | 新文字废弃旧 run/连接、只提交最新历史已测 | 真实语音/文字高频切换及云端资源释放 |
| A20 新增只读工具 | 仅注册新的受信任 adapter/schema/spec 即可执行，测试通过；未修改聊天核心/语音协议 | 实际新增供应商的完整业务验收 |
| A21 缓冲/时钟异常 | 缓冲硬上限、清空、定长帧、静音零值、连续采集已测；代码处理后台/离线/采集停顿 | 慢网、系统休眠、实际设备时钟漂移专项 |
| A22 误读数值/绕过桥接 | Agent 答案、实际语音字幕和估计播放记录分开保存/显示 | 真实口述事实一致率及桥接率，完全未测 |

## 测试资料与结果边界

`tests/fixtures/voice-evaluation-cases.jsonl` 包含 100 条人工编写的**合成测试文本**：40 天气、30 知识、20 混合表达、10 澄清/打断。尚无录音和真实执行结果，不能据此计算成功率。`scripts/score_voice_evaluation.py` 仅聚合已经观测、标记 `real_service=true` 的人工评审字段。

已生成本地桌面/窄屏截图 `artifacts/portal-desktop.png`、`artifacts/portal-mobile.png`，已进行视觉检查。截图中的“联调示例”不是客户数据或真实业务政策；测试产物不提交到仓库。

## 已修复的验证问题

- 配置根目录层级错误导致找不到 prompt/YAML；已按实际目录修复。
- Ant Design 属性不匹配导致 TypeScript 构建失败；已使用锁定版本支持的属性。
- WebSocket 被取消时清理过程再次受取消影响；已屏蔽清理期间的重复取消，并验证正常释放。
- 重复 interrupt 可能误取消新 run；已区分是否实际执行了 epoch 变更。
- 新 session 的 SSE clear 可能晚于 ready，错误屏蔽新播放；已仅清理旧 epoch。
- 仅关闭 access log 不能阻止 Uvicorn WebSocket 握手日志显示 ticket；增加 ticket/code/state 脱敏过滤及回归测试。
- 总业务时限原先只覆盖 SDK 循环；已在 SessionCoordinator 补充整轮 Runtime 的总预算。

## 交付限制

1. 缺少真实 VoiceChat、文本模型、RAG、天气及 SSO 配置，不能宣布完成云端集成或可直接上线。
2. 天气实现的是本项目 HTTP 代理契约，尚未对接一个已指定的真实天气厂商；现有 RAG 路径若不同也需集中映射。
3. 原生自由口述可能绕过桥接或改写结果，引用存在性也不证明每个结论正确；严格政策/数字口述仍需专项评测或人工处理。
4. 多副本要求粘性路由；Redis 租约、PostgreSQL 行锁及容量必须在目标部署实测。每副本容量不能直接当作云端总容量。
5. 云端运行方式已固定为 `deploy/compose.production.yaml`；本地机器没有 Docker，因此只完成生产 Compose 静态契约检查，尚未完成镜像构建和云端容器健康验收。
