# 面向客户的全双工语音客服：实现审查与集成提案

日期：2026-09-15。状态：**审查完成，方案待确认；未修改应用代码、未部署、未执行真实服务联调。**

本文维护本轮审查发现及拟议增量，现有架构和一期实现记录仍见 `VoiceChat_AgentsSDK_Codex_Design.md`、`implementation-plan.md`。确认实施时，将已批准决策归并到主设计并更新实施计划，避免两份生效规范。

## 1. 结论与系统定位

目标是三个独立系统组合提供面向客户的语音客服：

| 系统 | 职责 | 服务边界 |
| --- | --- | --- |
| Voice Service Agent（本项目） | 客户 Web 入口、身份权限、会话、业务回答、证据展示、工具编排、打断与恢复、审计 | 对客户提供 HTTPS/WSS；服务端调用模型和知识系统 |
| NVIDIA VoiceChat | 流式语音理解、自然接话、语音生成、原生工具调用 | 独立启动，通过已部署版本的实时 API 提供服务 |
| CueKB | 有权限、版本和来源约束的知识证据检索 | 独立启动，通过 `POST /v1/search` 返回证据 |

**现有分层可沿用，但尚未形成这三个系统的真实闭环，也尚未证明满足客户自然全双工体验。** 首要工作是接口适配与能力验证，无须重建知识库或把 VoiceChat 模型装进本项目。

**本轮已确认的业务范围：** 客服系统包括两类能力：① 对接 CueKB 的本地知识库检索；② 对接第三方系统的扩展能力，例如天气、股票查询。第三方扩展机制属于正式架构；具体工具按实际部署配置启用。只接入 CueKB 的部署只能进行知识问答，不能声称具备天气或股票的实时查询能力。天气不是所有部署的必需依赖，也不代表第三方工具仅限于天气。

保留已确认的中文分工：中文能力由部署的语音服务提供，本项目负责无损传输、编排和端到端验证，不训练模型、不引入 CUDA/NeMo、不删除中文。公开原始模型的语言说明不能证明目标部署已支持中文，必须记录实际版本和音频往返结果。

现有 `BusinessRuntime` 使用独立文本模型生成有证据的答案。**三套业务系统并不等于只有三个运行进程，也不意味着已经没有文本模型依赖。** 文本模型是本项目的推理依赖；可通过现有 compatible adapter 使用经过契约验证的独立文本服务。VoiceChat 的 WSS 地址不能代替文本模型 HTTP 地址。

## 2. 检查范围与证据

- 本项目 HEAD：`d767fcb5bc55fc697a462b7119beaa0c597fc1ae`；检查开始时工作区干净。
- CueKB：本机 `/Users/snowking/Documents/CueKB`，HEAD `22c74a335bf88ea50f0df3b171d0b2125c14c77a`，检查时工作区干净。已阅读核心文档、任务板、API_GUIDE、schema、路由、认证和检索实现；未修改 CueKB。
- VoiceChat：核对 NVIDIA 官方 `nemotron-labs-voicechat` 分支 API Reference、README Known Limitations 和模型卡；参照本项目此前固定的协议版本。公开分支是可变资料，部署前仍须固定目标容器 digest、代码 revision 和 API 样例。
- 本机 `/Users/snowking/Documents/speech/s2s/audio_server.py` 仅作为辅助实现参考；该目录不是 Git checkout，不能把其中代码冒充目标服务器版本。

### 2.1 已实现且应保留的部分

- `voice/provider.py`：握手、24 kHz PCM16 格式校验、事件映射、同 `call_id` 工具结果写回。
- `voice/gateway.py`：音频/控制队列、单写入器、独立工具 worker、一次性票据、晚到结果隔离。
- `sessions/coordinator.py`、`storage/store.py`：同会话任务管理、epoch/turn 校验、幂等和历史事务。
- `agent_runtime/runtime.py`、`tools/registry.py`：文字/语音共用业务 Runtime、工具权限和预算、引用存在性校验。
- `apps/web/src/audio/VoiceClient.ts` 及 AudioWorklet：连续采集、重采样、连续播放、缓冲清理、静音与断线释放。
- `api/auth.py`：认证后的会话归属及知识库范围；当前定位是组织内客服人员。
- `deploy/compose.production.yaml`：应用 PostgreSQL、Redis、迁移、API 和 Web 的独立 Compose 部署。

### 2.2 集成缺口

优先级表示对本次目标的影响，不表示已经发生生产事故。

| 优先级 | 发现与源码位置 | 影响与处置方向 |
| --- | --- | --- |
| P0 | `tools/adapters.py:82` 请求 `/v1/retrieve`；CueKB `api/routes.py:283` 实际是 `/v1/search` | 指向 CueKB 根地址会请求错误路径。新增专用映射，同时修改 schema，不能只换 URL |
| P0 | 本项目 `tools/schemas.py` 要求 request_id/retrieval_id/status，以及 score/title/version/updated_at；CueKB 返回 trace_id/retrieval_status/evidence_status/version_id/source_text/anchor 等 | 直接解析必定不兼容。保留 CueKB 的降级、版本和定位信息，不伪造缺失字段 |
| P0 | 本项目传 X-Tenant-ID/X-User-ID；CueKB `api/dependencies.py:63` 依据 API Key 解析 principal，不读取这些头作为身份 | 服务 Key 权限和客户权限必须明确映射；这些头不能被描述成 CueKB 已执行客户级 ACL |
| P0 | `voice/gateway.py:229` 的 input.state 只更新状态，前端也只展示；按钮才执行清音、取消、重连 | 普通播放依赖模型让话，工具等待时没有自动语义取消；不能将“持续收音”描述成所有阶段可自然打断 |
| P0 | `api/auth.py:70` 只授予 operator/admin 权限 | 当前是客服工作台身份模型，需要增加客户访问策略；不应给客户分配 operator/admin 角色绕过限制 |
| P1 | `config.py` 生产校验强制天气 real、地址和密钥 | 与“两类能力、具体工具按需接入”的需求不符；保留第三方扩展架构，只对启用工具校验配置，禁用工具不参与依赖和 mock 状态计算 |
| P1 | `agent_runtime/runtime.py:128` 只校验引用和工具记录；原生音频直接转发 | 有引用不能保证结论被证据支持；业务 speech_text 也不能保证 VoiceChat 最终逐字口述 |
| P1 | `config.py:51` 默认 105 秒；gateway watchdog 到时直接结束 | 当前没有安静边界轮换或无损续接。客服长会话必须专测，不能称为透明恢复 |
| P1 | CueKB `retrieval.py:193` 当前 context 等于 source_text，evidence_status 为 unassessed | include_context=true 不代表已补齐表头、相邻步骤或父章节；完整上下文和证据评估仍是 CueKB 待实现范围 |
| P2 | gateway 的多个音频路径反复检查 Redis 归属及 SQL epoch | 持续 PCM 下有控制面开销；先测单会话和并发延迟，再考虑在不削弱写回隔离的前提下优化，当前不能断言是性能瓶颈 |

## 3. 推荐架构与两条调用链

```text
客户 Web ── HTTPS / WSS ── Voice Service Agent
                            ├─ 认证、会话与输出控制
                            ├─ VoiceGateway / VoiceChatAdapter ⇄ 独立 VoiceChat
                            ├─ BusinessRuntime → 文本模型服务
                            │                    ↓ 工具调用
                            │              ToolRegistry
                            │                ├─ CueKBAdapter → 独立 CueKB
                            │                └─ 第三方 Adapter → 已接入的第三方系统
                            └─ PostgreSQL / Redis：应用历史、审计、会话归属

独立 CueKB：API / Worker / PostgreSQL / OpenSearch / Embedding（按需重排）
独立 VoiceChat：由语音服务自己的部署维护模型与 GPU 运行栈
```

知识内容、权限和已发布版本由 CueKB 管理；本项目不直接读取其数据库、索引或文档存储。两套 PostgreSQL 的职责和迁移独立。

### 3.1 语音问答

1. 客户通过客服系统登录或受限访客会话进入 Web；服务端解析身份并计算可检索知识库。
2. 创建业务 conversation，签发绑定身份/Origin/epoch 的一次性语音票据。
3. 网关连接 VoiceChat，完成 session.created → session.update → session.updated；首次配置提示词和 `consult_service_agent`。
4. Web 持续发送音频，网关持续转发 VoiceChat 音频和字幕；查询期间保持音频任务运行。
5. 原生 function call 到达后，以连接、epoch、call_id 去重；将 `user_request` 交给现有 SessionCoordinator 和 BusinessRuntime。
6. Runtime 按实际授权工具选择 CueKB 检索或第三方查询；知识适配器从服务端上下文注入知识库范围，第三方适配器按供应商契约查询，二者都从服务端获取凭据和权限。
7. 根据证据生成文字答案、引用和短口述；提交前核对 epoch/turn/租约和授权状态。
8. 单写入器再次核对有效 pending call，将短结果通过同 call_id 返回 VoiceChat；模型生成语音，Web 播放。
9. 分别记录业务答案、模型实际语音字幕和浏览器估计播放进度。工具先于最终转写时，最终转写仅留档，不重复启动业务查询。

### 3.2 文字问答与架构取舍

文字 → SessionCoordinator → 同一 BusinessRuntime → CueKB → 有引用的文字答案。现状提交文字会停止语音，这一点在客户入口中应明确呈现；未来支持同时输入时必须先定义话轮竞争规则。

第三方问题走相同文字/语音入口，经同一 Runtime 和 ToolRegistry 调用对应适配器。组合问题可以先查 CueKB 再查已接入的第三方系统，受同一轮总预算约束；没有实际工具的部分明确说明能力范围，不用知识库旧资料或模型常识冒充实时查询。

本期建议保留 BusinessRuntime 和文本模型：它已经承担统一文字入口、证据回答、澄清和结果校验。另一种可行接法是 VoiceChat 直接调用知识检索工具，由 VoiceChat 根据证据生成回答；它可以减少语音业务链中的一次外部模型编排，但会削弱现有统一回答校验，文字入口仍需回答能力，而且不能解决工具阶段打断和口述偏差。本轮不默认改成此架构，可在真实样本中比较时延和正确率后再作决策。

### 3.3 第三方能力扩展是正式模块

复用当前 `ToolRegistry + ToolSpec + trusted adapter`，不为天气、股票各写一套会话或语音主流程。VoiceChat 继续只调用统一 `consult_service_agent`，后台 Runtime 根据当前工具集合选取知识检索或第三方工具。

| 部署情况 | 对客户开放的业务能力 | 启动和调用行为 |
| --- | --- | --- |
| 只配置 CueKB | 知识检索和有依据回答 | 不要求天气/股票凭据；询问实时天气或股票时明确当前未接入 |
| CueKB + 天气供应商 | 知识问答、天气查询 | 仅向获授权用户的 Runtime 提供天气工具 |
| CueKB + 股票供应商 | 知识问答、股票信息查询 | 仅提供该供应商真实支持的数据范围；保留市场、币种和数据时间等来源字段 |
| 某已接入工具暂时故障 | 其他可用能力继续服务 | 对该工具返回“暂不可用”；区分未接入、无权限、停用和运行故障 |

每个工具接入包含以下内容：

1. 服务端注册工具名称、用途、input/output schema、权限 scope、endpoint/secret 引用、版本、超时、重试和结果预算。
2. 适配器按真实第三方 API 处理鉴权、请求/响应和错误；映射到本项目领域结果。已有可信 adapter 的新配置可以复用；完全不同的协议仍需编写适配器及测试，不能承诺任意 URL 零代码接入。
3. 配置/管理状态区分未配置、已配置未验证、启用、停用和暂不可用；健康探测仅说明可达，真实业务测试通过才形成接入证据。
4. 创建 run 时固定工具配置版本；实际授权集合由部署注册、启用状态、有效配置、用户权限共同决定，执行前再次验证。工具停用、修订或客户撤权后，旧 run 不得继续执行或回传旧结果。
5. 对启用工具检查必要的服务配置，生产禁止其使用 mock。未启用工具不进入必需依赖检查、可调用列表或全局 mock 状态；单个供应商运行故障不使其他工具失效。
6. 新工具提供对应的事实校验规则和展示卡片；通用来源记录保留 provider、查询条件、获取时间、适用时间、状态与是否过期。具体业务字段由实际 API 决定，不把股票等工具硬套 WeatherResponse。

现有注册层已有上述部分基础，但工厂只注册 `rag_http` 和 `weather_http`；`BusinessRuntime.validate` 的证据检查仍主要面向知识引用/天气卡片。后续要将结构化第三方结果纳入可验证的工具结果契约，不能仅通过“有任意 card”判定业务事实成立。管理健康探测目前统一拼接 `/health`，需要由适配器定义，因为不同供应商不一定有这个路径。

VoiceChat 首次 instructions 应包含按权限计算的能力摘要；SDK 工具列表从后台实际配置生成。当前会话中工具被撤销时，后端校验必须立即生效，不依赖模型记住配置变化；新增能力可以在受控重连后的首次配置中更新。未接入的实时能力不由 VoiceChat 自行补答。

## 4. CueKB 适配设计

### 4.1 请求：使用已实现 API

```http
POST {CUEKB_BASE_URL}/v1/search
Authorization: Bearer <server-side scoped API key>
Content-Type: application/json
```

```json
{
  "query": "用户当前问题及必要的已确认条件",
  "kb_ids": ["00000000-0000-4000-8000-000000000001"],
  "mode": "auto",
  "top_k": 5,
  "filters": {},
  "include_context": true
}
```

UUID 仅示例，实施时换为服务端授权映射中的真实 UUID；当前默认 `kb_support` 不能直接传给 CueKB。不发送自造的 request_id/locale/deadline 字段并假定上游处理。

- `mode=auto` 作为首期默认，复用 CueKB 现有 exact/hybrid 路由；不在语音 Agent 内重新建设检索算法。
- product_model、software_version 仅来源于明确输入或已确认业务上下文；歧义先澄清，再映射到 CueKB 支持的 filters。
- 模型工具参数可以扩展为查询条件，但不得包含或覆盖 tenant、customer、kb_ids、endpoint、凭据。
- 首期不使用 `related` 冒充已实现关系扩展，不在本项目补建 CueKB 的 M3/M4 能力。

### 4.2 响应：保留证据语义

| CueKB 字段 | 本项目内部映射 |
| --- | --- |
| trace_id | retrieval trace；另保留本项目 request/run ID，建立两者关联，不要求上游回显不存在的 request_id |
| retrieval_status | 原样保留 ok/degraded/not_found，另行决定 answer_status |
| evidence_status | 原样保留；unassessed 不转成 sufficient |
| degraded_reasons、scope_limited | 写入检索审计，必要时影响是否回答或要求补充 |
| content_revisions | 保存知识库内容版本快照线索；不是事务一致性的承诺 |
| document_id、chunk_id、version_id | 引用的真实身份，保留版本 UUID |
| source_text、context | 证据原文与上下文分开；相同时不重复消耗预算 |
| title_path、anchor | 章节、页码、原文定位；标题缺失时展示“来源片段”，不捏造文档标题 |
| metadata.business_version 等 | 可选业务适用条件，与 version_id 区分 |
| rank、retrieval_sources | 排名与召回来源，不能当作事实置信度 |
| timings_ms、retrieval_path、executed_stages、skipped_stages | 调试和性能记录，客户界面不展示内部步骤 |

现有 Citation 强制要求 updated_at，CueKB 搜索结果没有该字段；应演进内部契约为可选，而不是填当前时间。缺少 score 不制造分数。新 citation_id 仍由本项目为本轮答案生成。若扩展持久化字段，按实际 storage 变更决定 Alembic 迁移；历史 JSON 应有明确版本/缺省读取策略，不批量伪造历史元数据。

来源链接建议走本项目的鉴权代理：先验证客户对本轮引用和知识库的访问权，再用服务端 Key 调用 CueKB 原件接口并指定检索得到的 version_id。该代理是待实现接口；不能把需要 Bearer Key 的内部下载 URL 直接给客户，不能通过 URL 暴露 Key。历史版本下载仍需权限和保留策略，不能默默改成当前版本导致引用错位。

### 4.3 身份与权限

推荐首期为客户可见资料建立独立知识库及仅有 read 权限的服务主体，避免业务应用 Key 获得管理或内部全库权限。有效查询范围为：认证服务授予的客户范围 ∩ 本项目部署允许范围 ∩ CueKB 服务主体可读范围。

- CueKB 当前认证的是 API Key 主体，前两层交集由本项目强制执行，第三层由 CueKB 执行。
- 多个客户权限完全相同时可以使用同一受限服务 Key；范围不同时，按隔离边界选取服务端配置的 Key/知识库集合，或另行设计 CueKB 支持的委托身份协议。
- 当前代码只部署一个 tenant；若扩展到多组织，需单独设计身份到实例/凭据的可信映射。首期可以每组织独立部署，不能凭增加一个请求头宣称多租户贯通。
- 检索返回前 CueKB 会再检查 Key 与 KB ACL，但当前返回没有统一的客户授权版本令牌。保存请求的服务端授权上下文，返回答案和取原文前复核客户权限；内容版本在检索后变化的严格最终复验如有需求，需要明确 CueKB 扩展或有界重查策略。
- 已展示的历史证据包含资料副本，撤权后的历史读取策略需要覆盖引用正文和原件，不能只阻止新检索。

### 4.4 空结果、降级、错误和预算

- not_found：本次合法检索未命中，回答依据不足或澄清；不等于业务事实不存在。
- degraded 且有 hits：保留原因，判断当前证据是否可用；不能静默包装成完全正常，也不必一律丢弃合法证据。
- unassessed：回答模块仍须逐项检查适用条件和引用支持；有证据不等于充分。
- 401/403：配置或授权失败；422：契约或参数错误；429：负载限制；5xx/超时：服务失败。不得把这些都变成“查无资料”。
- 保留现有 5 秒工具预算与 12 秒业务预算作为初始上限，最终值由实测确定。重试必须在剩余总预算内，只对合适的瞬态错误有界执行。
- 原 HTTP JSON 上限 32 KiB、模型证据 6000 字符是两种不同预算；中文 UTF-8、anchor/context 开销须实测。规定可配置传输硬上限和独立模型上下文上限，避免合法响应因适配层大小假设被全部拒绝。
- CueKB 全链路硬截止与服务端取消仍列为 M4 待开始。本项目取消 HTTP 等待不能被记录为 CueKB 后台工作已停止；晚到结果必须失效。

## 5. 全双工交互与 VoiceChat API 边界

在线协议基线为 `/v1/realtime` WSS、24 kHz mono PCM16 LE、推荐 80 ms 块；知识返回走 `conversation.item.create` 的 function_call_output，匹配原 call_id。动态 instructions、任意文本 TTS、response.cancel 不能按完整 OpenAI Realtime 协议直接假定可用。[官方 API Reference](https://github.com/NVIDIA-NeMo/Speech/blob/nemotron-labs-voicechat/voicechat_realtime_instructions/api-reference.md)

官方 Known Limitations 仍记录工具执行期间不可打断，以及上下文窗口、工具选择和口述可靠性限制。最新模型卡的等待提示语与公开代码的部分异步插话路径需要分阶段解释，详见 §10.10；不能将限制仅理解为外部 HTTP 不可取消，也不能推断所有推理实现均无任何插话支持。本方案将“自然插话”设为部署版本的独立验收门槛。[官方限制说明](https://github.com/NVIDIA-NeMo/Speech/blob/nemotron-labs-voicechat/README.md#known-limitations)

### 5.1 将验收分为三个层次

| 层次 | 要验证的行为 | 当前结论 |
| --- | --- | --- |
| 媒体全双工 | 播放、等待工具时麦克风仍连续上传 | 应用结构具备；真实服务未测 |
| 普通话轮全双工 | 用户在回答中插话，旧音频及时停止；短暂停顿、附和不误取消 | 依赖模型行为；浏览器未实现自动话轮控制，真实未测 |
| 业务全双工 | 检索期间修正型号/问题，旧任务作废，新条件被理解且旧结果不播 | 当前只有按钮重连确定性路径；官方基线不能保证自然无缝处理 |

目标应覆盖三层。只完成按钮重连的版本可以进行受限试点，不能标记为完整自然全双工验收通过。

### 5.2 控制策略

保留独立的 connection/input/output/business 状态，新增明确的“停止播报”“取消当前查询”“修改查询条件”语义。它们是本项目拟议动作，不是新造 VoiceChat 原生事件。

- 停止播报：立即清浏览器输出并屏蔽旧 response 的晚到音频；若仅不想听，是否继续查询应由明确动作决定。
- 取消/改问：先使旧业务任务失效，再取消本地等待；供应商没有可靠取消能力时关闭旧连接并恢复业务摘要。
- 将连接/音频 epoch 与业务 request revision 分开；当前 epoch 同时承载取消和重连，后续需避免“只停播放”误取消检索。提交和输出检查 conversation、task revision、turn、epoch、租约及权限。
- 普通插话可用本地语音活动信号先降低音量/抑制播放，再用服务端语音/转写和语义确认；不能仅凭音量把咳嗽、回声或“嗯”判成取消。检测算法与阈值必须通过真实设备测试。
- 工具期间若上游不提供可靠的新输入/取消语义，本地 VAD 只能做保守输出保护和受控恢复，无法保证理解用户改问。不能用提示词或增加子 Agent 宣称解决。
- 无有效 pending call 时不回写检索结果；不先返回 accepted 就假设稍后可再推送结果。后台结果注入须有版本化上游协议且通过竞态测试。
- 重连期间默认明确提示等就绪再说。若要接续已说出的前半句，须另行验证短时内存音频缓冲、时间线和上游重放契约，不盲目重播。

### 5.3 长会话和口述质量

对应用 105 秒轮换改为：接近预算时在安静、无 pending 工具和输出已排空的边界轮换，同时保留上游硬时限的强制清理；实际值由目标部署决定。两分钟训练窗口不是 API 固定断开时长。

业务回答先保留型号、版本、否定条件、数值和例外，再生成简短口述。引用校验之外增加业务样本级支持性评估；不能只在 display_text 上验引用而放任 speech_text 改变关键事实。原生流式语音仍可能改写结果，字幕事后审计无法撤回已播放音频。严格逐字口述需求需要语音服务提供明确的受控输出能力，不能把 VoiceChat 当通用 TTS；未具备时保留文字核实及人工流程。

## 6. 客户 Web 与客服系统集成

- 客户界面：开始/结束语音、输入状态、查询状态、字幕、简短答案及来源、文字补充、明确错误恢复。原有管理工具放在独立管理入口，服务端继续强制授权。
- 身份：优先复用客服系统签名身份，通过后端验证或兑换为本项目会话；访客仅访问公开知识范围。当前 operator/admin 模型需要扩展；不得信任浏览器正文中的 customer_id 或 kb_ids。
- 嵌入：先以同源 HTTPS 页面或客服系统反向代理接入，复用当前 Origin/安全 Cookie 设计。跨域 iframe 若需支持，要单独验证 frame 来源、麦克风 Permissions Policy、Cookie 和登录票据，不能直接放开所有 CORS/Origin。
- 人工衔接：设计可携带 conversation_id、问题摘要、引用和失败原因的交接上下文；实际客服系统未给接口，本轮不假设已经转接成功。首期明确区分“建议人工处理”与“已进入人工队列”。
- 工具范围：知识检索与第三方扩展是两类正式能力；客户仅看到当前已接入且获授权的能力，天气、股票等分别按需启用。退款、账户修改等写操作需有独立业务授权和执行契约，不因加入扩展框架自动开放。

## 7. 部署与观测

沿用本项目 Compose 构建、迁移和运行；VoiceChat 与 CueKB 使用各自独立部署，本项目只配置受信任端点和凭据。应用网关通过 HTTPS/WSS 调用外部服务，浏览器不接触其服务 Key。

先完成单网关真实链路，再验证多副本粘性路由、Redis 租约丢失和 PostgreSQL 并发。当前会话/票据保存在网关内存，不能宣称任意副本可接续原媒体连接。对外总容量同时受语音服务、业务模型、CueKB 和网关容量约束，不能简单将每副本席位相加。

观测关联：conversation_id → turn/task revision → epoch/voice_session_id/native call_id → 业务 run → CueKB trace_id/document/version/chunk → answer_id/response_id/playback ack。只保存必要的结构化审计，不默认落原始音频或泄露凭据。

延迟分开统计：麦克风至上游、用户说完至工具请求、CueKB 检索、业务答案生成、结果写回至首段语音、浏览器播放缓冲、用户插话至实际停止。以 P50/P95 和并发数报告；知识问答延迟包含工具及业务模型时间，不能照搬模型闲聊响应速度。

## 8. 建议实施里程碑

以下是待确认的增量计划，不是已完成编码。

| 阶段 | 交付 | 进入下一阶段的证据 |
| --- | --- | --- |
| M0 接口冻结与语音能力探测 | 固定实际 VoiceChat 容器/API、CueKB OpenAPI、凭据范围；用独立服务验证中文、原生工具往返、普通/工具期间打断、旧连接隔离 | 保存事件和测量报告；明确完整全双工所需的上游增强范围 |
| M1 知识与工具框架 | CueKB adapter/schema、状态/引用映射、授权、原件代理、按启用工具校验配置、客户认证策略与第三方结果契约 | CueKB 真实授权检索与异常用例；只配置 CueKB 可运行；加入一个指定真实第三方 adapter 不改会话/语音核心 |
| M2 语音与业务闭环 | 经同 call_id 回写真实 CueKB 答案；改问失效、短口述、实际字幕/播放审计 | 真实中文问题到检索、业务答案和语音输出完整成功；旧答案不能混入 |
| M3 客户交互与连续会话 | 客户 Web、普通插话、工具期间恢复策略、安静边界轮换、客服系统衔接 | 真实设备和长会话验收；若上游限制未解决，业务全双工仍标未通过 |
| M4 生产验证 | Compose、迁移、容量、路由、限流、断网/撤权/故障演练和质量评测 | 实际环境报告，无真实数据不填 passed 或性能达标 |

重点用例：准确型号/版本、口语查询、无答案、冲突条件、表格单位、多步骤说明、401/403/429/超时、检索期间撤权/删除/版本发布、重复 call_id、结果恰逢打断、0.3/0.8/1.5 秒句中停顿、附和、回声、查询中改型号、断网、超过两分钟和连续多轮。业务事实支持率和实际口述一致率分别验收。

扩展专项用例：只配置 CueKB 时生产配置不要求第三方凭据；未接入天气/股票不能生成查询成功结果；按用户权限生成工具集合；单个工具故障不影响知识问答；停用/密钥轮换/配置修订后旧调用失效；新增适配器后两种入口复用同一核心链路。具体供应商未指定前只能验证框架契约，不能写成真实天气或股票集成已完成。

预计影响模块：`tools/`、`contracts.py`、`agent_runtime/`、`sessions/`、`voice/`、`api/auth.py`、`api/routes.py`、`config.py`、工具配置、前端音频/客户界面、相关契约/测试/部署文档。保留模块边界，按里程碑增量修改。

## 9. 本轮验证与下一步输入

2026-09-15 实际执行：44 项 Python 测试通过；6 项 Node 音频测试通过；Ruff 通过；TypeScript/Vite 构建通过。Python 有一条 Starlette/AnyIO 上游弃用警告，无失败。

本轮未执行：真实 VoiceChat、CueKB 联调、文本模型/SSO、真实麦克风播放、浏览器 E2E、PostgreSQL/Redis/Docker 部署、故障切换、长会话和并发性能。现有测试验证本项目契约/合成响应，不覆盖真实 CueKB `/v1/search` 适配；不能据 44 项通过推导集成已完成。

后续联调需由部署配置提供：VoiceChat WSS/health 与 API/容器版本、中文服务声明；CueKB Base URL、实际知识库 UUID 和受限 API Key；文本模型服务；客服系统身份与客户知识访问范围。凭据仅放部署密钥系统或受控环境变量，不写设计文档或聊天记录。

**推荐执行顺序：先验证 VoiceChat 能力边界，再完成 CueKB 适配和客户身份，最后以真实业务音频完成全双工与口述验收。**

## 10. 三个进一步问题：Tools、GPT-Live 委派与 Codex harness

补充日期：2026-09-15。状态：分析与设计，未实施。此节沿用知识检索、第三方扩展两类能力；不改变独立部署和中文服务分工。

### 10.1 结论

| 问题 | 分析结论 |
| --- | --- |
| CueKB 能否作为 VoiceChat Tools 接入 | **可以。** 将 CueKB 的 HTTP 检索封装成函数工具，由本项目服务端执行并写回原生 call_id；CueKB 无需变为模型或新增生成式回答服务 |
| 能否参考 GPT-Live 将任务委派给子 agent | **执行架构可行；完整交互体验有条件。** 后台 agent 调用 CueKB 可实现；等待期间连续交谈、接受改问、稍后注入结果，需要 VoiceChat 自身提供并验证相应语义 |
| 能否参考 Codex harness | **适合。** 借鉴有状态执行、上下文隔离、受限工具、任务生命周期和可观测事件；在本项目现有分层内增量实现，不能靠运行控制层补出模型未支持的实时协议 |

三者解决的是不同问题：Tool 定义“能执行什么”；子 agent 定义“谁负责判断和执行这项任务”；harness 定义“任务如何被授权、调度、取消、恢复和验收”。

### 10.2 CueKB 作为工具的两种接法

**接法 A：直接检索工具。**

```text
VoiceChat 生成 search_knowledge(query, 已确认条件) 调用
  → 本项目校验参数、注入授权 kb_ids
  → CueKBAdapter 调用 POST /v1/search
  → 精简证据、状态和适用条件
  → 原 call_id 的 function_call_output
  → VoiceChat 根据证据生成口述
```

这里的“直接”是 VoiceChat 直接选择检索工具，HTTP 请求仍由本项目执行。工具 schema 不包含 API Key、endpoint 或可自行扩大的知识库权限。NVIDIA API 允许注册函数并在收到函数调用事件后回传结果；不是模型自行执行任意 HTTP。[官方 VoiceChat API](https://github.com/NVIDIA-NeMo/Speech/blob/nemotron-labs-voicechat/voicechat_realtime_instructions/api-reference.md)

优点是少一层业务模型推理；适用于简短、单次可回答的检索。代价是更多业务判断及证据到答案的组织落在 VoiceChat 上；工具选择、条件核对和口述质量必须实测。直接返回大量检索片段还会增加模型处理和口述延迟，因此仍需适配与预算。

**接法 B：统一业务工具，内部调用 CueKB，推荐作为当前主线。**

```text
VoiceChat 调用 consult_service_agent(user_request)
  → SessionCoordinator 创建业务任务
  → BusinessRuntime（后台任务 agent）
      → search_knowledge → CueKBAdapter → CueKB
      → 已接入的第三方工具
  → 验证后的业务答案及短口述
  → 原 call_id 的 function_call_output
  → VoiceChat 输出语音
```

两种接法都属于 Tool Calling，区别只是原生工具返回“检索证据”还是“完成业务处理后的结果”。B 已有代码骨架，更符合统一知识/第三方能力及文字入口；需要补齐 CueKB 适配，不必重写会话主流程。A 可作为独立对照测试路径，生产不同时暴露语义重复的直接检索和业务委派工具，以免模型绕过预定的结果校验路径。

### 10.3 GPT-Live 1 可借鉴的实际设计

已核对官方 `gpt-live-1` 资料，没有将其替换成 GPT-Realtime。GPT-Live 将持续语音交谈与后台工作分开；client delegation 可接应用自己的模型、agent 或服务。这与保留本项目 Runtime 的方向相符。[GPT-Live 架构](https://developers.openai.com/api/docs/guides/live)

其 client delegation 有委派标识和结果追加通道；应用仍负责上下文、权限和任务状态。结果注入的确认不等于已经播完，语音打断也不自动取消后台工作。[GPT-Live 委派文档](https://developers.openai.com/api/docs/guides/live-delegation)

| 能力 | GPT-Live 的公开设计 | 当前 VoiceChat 路径 |
| --- | --- | --- |
| 交谈与后台处理分工 | 语音交谈与委派工作解耦 | 现有网关已把音频任务和业务 worker 分开 |
| 任务发起 | client delegation 事件；应用准备任务上下文 | 原生函数事件提供 name、arguments、call_id |
| 后台结果进入语音上下文 | 专门的 result/context append 通道 | 目前只有有效 pending call 的 function_call_output 路径 |
| 等待期间改问 | 语音交谈可继续；应用维护新任务条件 | 官方基线记录工具期间不可打断，目标部署未实测 |
| 取消与输出确认 | 应用负责取消和晚到结果处理 | 已有 epoch/turn 隔离；停止播放与取消业务尚需解耦 |

GPT-Live client delegation 事件本身提供元数据而非完整任务正文，不能假定其与 VoiceChat `arguments.user_request` 可逐字段互换。借鉴职责划分即可；`session.delegation.created`、`session.commentary.append` 等属于 GPT-Live 协议，**不得直接发送给 VoiceChat 并假定兼容**。

当前已安装 Agents SDK 的 `Agent.as_tool()` 实现会等待嵌套 `Runner.run()` 完成，启用 streaming 回调也仍等待子 run 结束再返回结果。因此它可以实现职责委派，却不会单独提供持续前台交谈和后台结果注入能力。官方将 agents-as-tools 定义为外层保留回答责任、专长 agent 提供有界能力；它与接管整个对话的 handoff 不同。[Agents SDK 编排](https://developers.openai.com/api/docs/guides/agents/orchestration)

### 10.4 推荐角色：先一个后台 agent，按需要增加专长 agent

```text
客户 Web ⇄ VoiceChat（交谈）
              ↕ 原生工具调用 / 合法结果回传
本项目会话控制层（harness，程序负责）
  ├─ SessionCoordinator：接单、改问、取消、当前任务版本
  ├─ BusinessRuntime：后台任务 agent，保持业务回答责任
  │    ├─ 简单查询：直接调用 CueKB 或第三方工具
  │    └─ 复杂知识任务：委派 KnowledgeAgent（按需增加）
  │                         → 只读知识工具 → CueKB
  ├─ Result validation：验证来源、权限、适用条件和任务时效
  └─ Output control：统一提交文字结果和语音回传
```

这里“后台任务 agent”相对前台语音交谈已是被委派的 agent，现有 `BusinessRuntime` 可以承担该角色，无须先增加一个只负责转发的模型。若确实需要独立知识子 agent，再从后台 Runtime 中拆出 KnowledgeAgent：

- 适用任务：比较多个版本、组合多个问题、补充检索、整理必要证据与缺失条件。
- 输入：当前问题、已确认条件、必要历史摘要、受限工具句柄和服务端任务上下文。
- 输出：证据、建议结论、适用条件、未解决问题和状态；建议结论仍需外层验证。
- 权限：只调用授权的知识工具，不可扩大 KB 范围，不调用未授权第三方接口。
- 边界：不直接播放、不写主会话历史、不向 VoiceChat 发送事件；只把结果交给协调层。
- 预算：首期一层委派，不允许递归派生；共享父任务剩余 deadline 和调用预算，不能每个子任务重新获得完整预算。简单检索不强制绕一层额外 LLM。
- 上下文：子任务保有自己的临时证据/卡片容器，只把验收后的结果合并给父任务，避免将所有原始中间输出回灌语音模型。

CueKB 仍是确定性检索服务，agent 推理放在本项目。股票或天气通常可直接调用适配器；只有业务规则、权限或多步骤流程确有差异时，才建立专长 agent。子 agent 可以与父 agent 使用相同模型，是否使用不同模型应由任务质量、时延和成本评测决定。

### 10.5 两级实施：pending 工具模式与完整异步委派

**A级：当前原生 API 下的可实施模式。**

保留 VoiceChat 的 pending call；后台 agent/知识子 agent 执行查询，音频队列继续处理；有结果时经检查按同一 call_id 返回。这能实现 Tools + 子 agent 的业务分工，但不能承诺工具等待期间自然改问。

**B级：以 GPT-Live 为参考的完整异步体验。**

在部署的 VoiceChat 上必须先获得以下契约及实测证据：

1. 委派发起后，模型仍持续理解用户新输入，而非只保持音频连接。
2. 后台任务结束时，有合法的关联结果注入机制；需要明确它是保留原 pending call 还是独立消息通道，不能伪造或重复终结 call。
3. 输入修正能被应用可靠观察，并更新业务任务版本；工具等待、结果到达及用户插话的竞态有定义。
4. 语音输出能按当前任务/回复识别和抑制，旧结果不能再次生成有效业务播报。

若目标服务只支持原 pending call，必须实测等待状态是否允许交谈；若不允许，就需要 VoiceChat 服务侧增强。单纯在外面增加 HTTP 代理或把 await 改成 create_task，不能改变模型等待状态。B 级不通过时，采用 A 级及明确的取消/重连恢复，完整异步体验仍标未达成。

### 10.6 任务状态、改问与输出控制

以下都是拟议的本项目内部契约，不是 NVIDIA 或 CueKB 新字段。

**任务：** `task_id`、`parent_task_id`、`conversation_id`、`origin_turn_id`、`request_revision`、服务端身份/授权快照引用、`context_version`、工具版本、deadline、预算、状态、取消原因、证据引用。与供应商的 native call_id 单独关联。

**执行状态：** queued → running → completed / failed / canceled / expired；修正旧问题可标 superseded。

**输出状态：** pending_validation → accepted / discarded；接受后另跟踪 text_published、voice_submitted、playback_estimated / interrupted / delivery_unknown。任务计算完成与结果送达分开，不以一次函数返回视为客户已收到完整答案。

| 用户输入 | 任务处理 | 语音处理 |
| --- | --- | --- |
| “先别说，结果显示出来就行” | 查询可继续 | 停播并取消该任务的自动语音交付，不取消有效查询 |
| “不用查了” | 使任务失效并取消本地执行 | 屏蔽该任务的晚到输出；上游取消未确认时不声称全部计算已停止 |
| “不是 X1，是 X2” | request revision 增加，X1 任务 superseded；按 X2 新建/继续受控任务 | 丢弃 X1 结果，只允许 X2 结果进入输出；是否能自然完成取决于 B 级能力 |
| “嗯”或短暂停顿 | 默认不改变查询条件；必要时澄清 | 不仅凭音量取消任务 |

业务结果接受时检查任务 revision、状态、deadline、授权和证据；语音交付时再检查当前连接/音频 epoch、有效 call、回复状态和租约。**两次检查分开：** 仅停止播放不必使仍有效的知识结果作废；重连后也不能把旧 call_id 搬到新连接。新连接只能通过其支持的合法路径重新交付。

数据库通过唯一结果键和条件状态更新，保证重复完成事件不重复提交答案；发送端在写回前再次校验。持久 outbox 可以支持业务事件恢复，不能自动重放旧音频或已失效的工具结果。网络断开导致送达状态未知时保留 unknown，不盲重发以宣称 exactly-once。

### 10.7 Codex harness：适合借鉴的运行控制层

本节将 harness 定义为模型之外的执行程序：维护上下文和任务，调用工具，接收用户修正，控制预算，验收和提交结果。依据公开 Codex App Server 的 thread/turn/item、事件流、恢复和中断接口以及子 agent 上下文隔离说明进行设计映射；以下客服实现属于本项目方案，并非声明复刻 Codex 的全部内部实现。[App Server](https://learn.chatgpt.com/docs/app-server)、[子 agent 说明](https://learn.chatgpt.com/docs/agent-configuration/subagents)

| 可借鉴机制 | 本项目已有基础 | 建议增量 |
| --- | --- | --- |
| 会话、请求、事件分层 | Conversation、Turn、Event、Record | 增加任务父子关系和 request revision，区分执行/交付状态 |
| 有界 agent loop | Runner、max_turns=8、总时限 | 父子任务共享预算，防止拆分任务绕过调用上限 |
| 上下文管理 | history、summary、slots | 分开交谈摘要、当前任务条件、证据与未解决问题；过期检索结果不作为当前事实 |
| 受限工具 | ToolRegistry、scope、server endpoint | 按部署和用户生成能力集合，子 agent 只能缩小权限 |
| 任务委派 | 独立业务 worker | 有界子任务执行、独立临时上下文、结果验证后合并 |
| 中断和用户修正 | epoch、task.cancel | 区分停止播报/取消查询/修改条件；协议不支持 mid-turn steering 时在应用层失效并重启任务 |
| 结果提交 | Store.commit 和单写入器 | 主会话单一提交者、原子接受结果、输出二次检查 |
| 恢复与审计 | PostgreSQL、Redis 租约、SSE | 持久任务记录和事件关联；断线只恢复允许恢复的业务状态 |
| 验收机制 | 契约测试、证据校验 | 真实语音、权限撤销、时延、任务改写和输出竞态评测 |

适配到客服时，不把编程场景的 shell、任意文件操作、无限长自主执行或每次查询审批照搬进客户流程。本期工具为已授权只读查询；后续写业务另定义幂等、确认和结果核对契约。无需引入 Codex App Server 作为 VoiceChat 的生产依赖；现有 FastAPI/SessionCoordinator/Agents SDK 已能承载应用 harness。

### 10.8 现有实现中的改造约束

1. `SessionCoordinator.submit()` 会替换当前 turn 并取消旧 task。子任务不能直接复用该方法创建，否则可能取消自己的父任务；在同一协调模块提供受控的子任务执行路径。
2. `RunContext` 的 evidence/cards/slots 都是可变对象，ToolRegistry 失败时还会回滚它们。并行子任务必须有独立上下文，不共享这些容器；合并时重新编号和校验引用，防止互相覆盖或串证据。
3. `voice/gateway.py` 只接受一个未完成原生 call，且只实现 pending-call 回传。保持 A 级语义，不能在尚无协议支持时直接开放并行原生工具/后台推送。
4. `SessionCoordinator.execute()` 在 BusinessRuntime 返回后统一通过 Store 提交历史；知识子 agent 只返回候选结果，不能各自触发 portal.answer.final。
5. 任务持久化扩展使用 Alembic。默认在当前进程运行子任务，先验证容量和取消；需求没有证明必要前不引入新的消息队列或多 agent 服务集群。
6. 任何后台检索/第三方请求都复用 ToolRegistry 进行权限、契约和预算检查，不允许专长 agent 绕过适配器自行构造网络访问。

### 10.9 建议验证计划

- **P0 协议验证：** CueKB 工具往返；VoiceChat 在工具等待时持续说话/听取修正；合法结果注入；结果与插话竞态。逐项区分公开契约、目标部署声明与实测。
- **P1 A级闭环：** 完成 CueKBAdapter，现有 BusinessRuntime 作为后台任务 agent；知识/第三方按配置开放；比较直接工具与业务 agent 两种路径的事实正确性和时延。
- **P2 harness 增量：** 独立任务版本、停止播报/取消查询语义、状态持久化、上下文隔离和唯一结果提交；以旧任务晚到、重复完成、权限撤销和重启测试验收。
- **P3 专长子 agent：** 仅在复杂知识用例证明有收益后引入 KnowledgeAgent，和单 agent 基线比较引用完整性、错误率、总延迟和调用成本。
- **P4 B级交互：** 在语音服务通过能力门槛后，开放检索期间自然澄清/改问/结果回传；该能力未通过时不把增加子 agent 或 harness 视为替代验收。

本轮只核对官方资料、当前项目和已安装 SDK 源码，并扩充方案文档；未发起模型调用、未连接真实服务、未增加运行时代码，也未重复上一轮测试。上一轮 44 项测试等结果只保持其原验证范围。

### 10.10 工具等待时能否继续交谈：进一步核对

核对日期：2026-09-15。结论：应用管理工具生命周期、丢弃过期结果的方向正确；但“工具不可打断仅意味着 HTTP 请求不能取消，模型仍可自由交谈”不是目前已验证的服务契约。

**证据与边界：**

- [最新模型卡](https://huggingface.co/nvidia/NVIDIA-NemotronLabs-VoiceChat-11B/blob/main/README.md)描述工具执行时维持自然对话流，并说明可定义 on-hold message；本次页面显示的 README 修订为 `bd32b9997858b0acd9af64f26e4306cf91ad1c82`。其 Known Limitations 仍链接到官方仓库限制页。
- [部署文档 Function Calling](https://github.com/NVIDIA-NeMo/Speech/blob/nemotron-labs-voicechat/voicechat_realtime_instructions/deploy.md)将流程描述为暂停回答、请求工具结果、收到结果后恢复；`ack_messages` 用来在等待时发声。因此有等待提示语不等于能回答任意新问题。
- [公开 streaming pipeline](https://github.com/NVIDIA-NeMo/Speech/blob/nemotron-labs-voicechat/nemo/collections/speechlm2/inference/pipelines/streaming_s2s_pipeline.py)已有异步线程和插话处理；但外部工具阶段仍等待 future，主路径在线程存活时处理队列后返回。不能仅凭异步分支证明 API 等待期间能持续生成新回答。
- 本地 `/Users/snowking/Documents/speech/opt/tritonserver/backends/nemotron-voicechat/model.py:583` 的 Triton 快照在工具非 idle 状态将普通文本 token 置 PAD，另注入 ACK 和工具结果。该快照支持“等待提示语与自由回答不同”的判断，但本地目录无 Git 版本证据，不能代表用户当前云端镜像。

模型能力、Python streaming pipeline 和独立 WebSocket/Triton 服务不可混为同一实现。工具调用生成、外部执行等待、结果注入、答案播报也应分别验收。

**建议的应用行为：**

1. 用户明确修改条件或取消时，立即更新 `request_revision`，旧任务标记 `superseded` 或取消；无需等工具完成才决定失效。仅“嗯”等附和或停止播放不自动使查询失效。
2. 对不能确认已停止的外部执行，允许其在原预算内结束；返回结果只进入任务记录，是否提交给主会话需再次校验当前 revision、状态和授权。取消本地 await 不证明外部服务已停止。
3. 丢弃过期业务内容与结清原生 `call_id` 分开。不能简单不回复而让 VoiceChat 永久 pending；保留连接时须验证匹配 call_id 的失效说明是否能安全结束等待且不播报旧答案。该说明是应用工具输出内容，不是 NVIDIA 原生取消字段；若无法保证，采用已定义的关闭/重连恢复。
4. 新任务可在授权和容量范围内创建，是否能同时在原语音连接上接收改问、生成新工具调用并交付结果，仍由实际协议能力决定。不得向新连接写旧 call_id，也不得把立即回传“已受理”当成已有后续推送通道。

**最小真实验收：** 固定镜像 digest/API 配置，用明确标记的延迟测试工具将返回延后 5 秒；等待中分别测试无关新问题、修改查询条件、取消和附和。记录用户语音、转写、工具事件及实际输出音频，验证是否在旧工具返回前给出针对新问题的回答（ACK 不算），以及旧结果晚到、原 pending call 结束和后续新调用。通过该实验后再确认连续交谈能力；本次未执行此实验。
